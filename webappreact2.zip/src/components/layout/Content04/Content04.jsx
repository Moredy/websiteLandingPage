
import './Content04.css'
import ContactForm from'../Widgets/ContactForm/ContactForm'
export default props => {

  return (

    <div id="Content04" className="Content04">

      <ContactForm></ContactForm>

      </div>
    );
  }
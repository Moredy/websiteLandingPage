
import './Content03.css'
import Portfolio from '../Widgets/Portfolio/Portfolio'

export default props => {

  return (

    <div id="Content03" className="Content03">

        <h1><strong>CONFIRA ALGUNS DE MEUS PROJETOS</strong></h1>

       <Portfolio></Portfolio>
  
      
      </div>
    );
  }
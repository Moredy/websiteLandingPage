import React from 'react'
import './FirstColumn.css'
//import Button from '@material-ui/core/Button';

export default props => {

  return (
    <div className="FirstColumn">

      <h1>I' M MORED DOPE</h1>
      <p>WEB DEVELOPER</p>
      {//<button>COMPRAR ALGUMA COISA</button>
      }


    </div>
  );

}
import React from 'react'
import './MainMenu.css'


export default props => {

  return (

    <div className="MainMenu">
      <a href="#" class="btn">Home</a>
      <a href="#" class="btn">About</a>
      <a href="#" class="btn">Services</a>
      <a href="#" class="btn">Contact</a>
    </div>

  );

}
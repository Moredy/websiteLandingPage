import React from 'react'
import './SecondColumn.css'


export default props => {

  return (
    <div className="SecondColumn">


      <p>SECOND COLUMN</p>
      <p>SECOND COLUMN</p>
      <p>SECOND COLUMN</p>
      <p>SECOND COLUMN</p>
      <p>SECOND COLUMN</p>
      <p>SECOND COLUMN</p>
      <p>SECOND COLUMN</p>
      <p>SECOND COLUMN</p>
      <p>SECOND COLUMN</p>
      <p>SECOND COLUMN</p>
      <p>SECOND COLUMN</p>
      <p>SECOND COLUMN</p>
      <p>SECOND COLUMN</p>
      <p>SECOND COLUMN</p>



    </div>
  );

}
import React from 'react'
import './FrameContent.css'
import image01 from './moldura.png'


export default props => {

  return (
    <div className="FrameContent">

        <img className="FrameImage" src={image01}></img>
      
    </div>
    );

}
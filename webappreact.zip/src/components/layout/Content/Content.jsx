import React from 'react'
import './Content.css'
import FirstColumn from './FirstColumn/FirstColumn'
import SecondColumn from './SecondColumn/SecondColumn'
import FrameContent from './FrameContent/FrameContent'
import image01 from './undraw_welcome_cats_thqn.svg'




export default props => {

  return (
    <div className="Content">
      <FirstColumn></FirstColumn>
      <img className="imageTruck" src={image01}></img>
      <FrameContent></FrameContent>



    </div>
  );

}
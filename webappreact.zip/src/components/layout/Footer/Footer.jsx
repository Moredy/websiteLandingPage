import React from 'react'
import './Footer.css'

export default props => {

  return (
    <div className="Footer">


          <p>
           MORED QUE FEZ TODOS OS DIRETOS RESERVADOS ©
          </p>


          
      
    </div>
    );

}
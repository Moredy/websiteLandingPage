
import Link from '@material-ui/core/Link';
import Button from '../Widgets/ButtonContent03/Button';
import './Content03.css'

export default props => {

  return (

    <div className="Content03">

      <span style={{ cursor: 'not-allowed' }}>
        <Button className="ButtonSpan" component={Link} enable>
          ENABLEDDD
        </Button>
      </span>

    </div>
    );
  }
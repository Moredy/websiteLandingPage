
import Link from '@material-ui/core/Link';
import Button from '../Widgets/ButtonContent03/Button';
import './Content02.css'
import Card from '../Widgets/CardContent02/CardContent02'

export default props => {

  return (

    <div className="Content02">

       <h1>ALO GALERA DE COWBOY</h1>
       <Card></Card>
       <h1>AAAA</h1>

      </div>
    );
  }
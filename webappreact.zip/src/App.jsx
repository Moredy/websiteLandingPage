import logo from './logo.svg';
import './App.css';
import Header from './components/layout/Header/Header'
import Content from './components/layout/Content/Content'
import Content02 from './components/layout/Content02/Content02'
import Content03 from './components/layout/Content03/Content03'
import Footer from './components/layout/Footer/Footer'


function App() {
  return (

    
    <div className="App">
      <Header></Header>
      <Content></Content>
      <Content02></Content02>
      <Content03></Content03>
      <Footer></Footer>

    </div>
  );
}

export default App;
